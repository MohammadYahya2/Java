package Mammal;

public class test {

	public static void main(String[] args) {
		Gorilla g=new Gorilla(100);
		Bat b= new Bat(300);
		g.throwSomething();
		g.eatBananas();
		g.climb();
		b.attackTown();
		b.fly();
		b.eatHumans();
	}

}

package Mammal;
public class Mammal {
 protected int energy ;

public Mammal(int energy) {
	this.energy = energy;
}


public int getEnergy() {
	return energy;
}

public void setEnergy(int energy) {
	this.energy = energy;
}
 
}

package com.example.savetravels;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SavetravelsApplication {

	public static void main(String[] args) {
		SpringApplication.run(SavetravelsApplication.class, args);
	}

}

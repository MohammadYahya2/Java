package com.example.ninjagoldgame.Controller;

public class ninjagoldgame {

}

package com.example.ninjagoldgame;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NinjagoldgameApplication {

	public static void main(String[] args) {
		SpringApplication.run(NinjagoldgameApplication.class, args);
	}

}

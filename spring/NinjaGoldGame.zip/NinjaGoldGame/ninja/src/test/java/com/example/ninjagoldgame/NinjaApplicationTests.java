package com.example.ninjagoldgame;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NinjaApplicationTests {

	@Test
	void contextLoads() {
	}

}
